<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Person extends Model
{
    // The table associated with the model (optional if the table name is 'people')
    protected $table = 'people';

    // The attributes that are mass assignable
    protected $fillable = [
        'name',
        'email',
        'phone',
        'gender',
        'image',
    ];
}
