<?php

use App\Http\Controllers\PersonController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/people', [PersonController::class, 'index'])->name('people.index');
Route::post('/people', 'PersonController@store')->name('people.store');
Route::post('/people/{id}', 'PersonController@update')->name('people.update'); // Route for updating a person
Route::delete('/people/{id}', 'PersonController@destroy')->name('people.destroy'); // Route for deleting a person
Route::get('/people/{id}/edit', 'PersonController@edit')->name('people.edit'); // Route for editing a person


