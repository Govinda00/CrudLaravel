<!DOCTYPE html>
<html>
<head>
    <title>Laravel AJAX CRUD</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Laravel AJAX CRUD</h2>
        <div id="successMessage"></div>
        <form id="personForm">
            <input type="hidden" id="personId">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <input type="text" class="form-control" id="phone" name="phone">
            </div>
            <div class="form-group">
                <label>Gender:</label><br>
                <input type="radio" name="gender" value="Male" required> Male
                <input type="radio" name="gender" value="Female"> Female
            </div>
            <div class="form-group">
                <label>Image:</label>
                <input type="file" class="form-control" id="image" name="image">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <hr>
        <h3>People List</h3>
        <input type="text" id="search" placeholder="Search by name, email, gender" class="form-control mb-3">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="peopleTable">
            </tbody>
        </table>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            // Add CSRF token setup
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            fetchPeople();

            function fetchPeople() {
                $.ajax({
                    url: "<?php echo e(route('people.index')); ?>",
                    method: 'GET',
                    success: function (response) {
                        $('#peopleTable').html(response);
                    }
                });
            }

            $('#personForm').on('submit', function (e) {
                e.preventDefault();
                let formData = new FormData(this);
                let personId = $('#personId').val();

                console.log(formData);
                if (personId) {
                    $.ajax({
                        url: `/people/${personId}`,
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (response) {
                            $('#successMessage').html('<div class="alert alert-success">' + response.success + '</div>');
                            fetchPeople();
                            $('#personForm')[0].reset();
                            $('#personId').val('');
                        }
                    });
                } else {
                    $.ajax({
                        url: "<?php echo e(route('people.store')); ?>",
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (response) {
                            $('#successMessage').html('<div class="alert alert-success">' + response.success + '</div>');
                            fetchPeople();
                            $('#personForm')[0].reset();
                        }
                    });
                }
            });

            $(document).on('click', '.edit-btn', function () {
                let personId = $(this).data('id');
                $.ajax({
                    url: `/people/${personId}/edit`,
                    method: 'GET',
                    success: function (response) {
                        $('#personId').val(response.id);
                        $('#name').val(response.name);
                        $('#email').val(response.email);
                        $('#phone').val(response.phone);
                        $("input[name=gender][value=" + response.gender + "]").prop('checked', true);
                    }
                });
            });

            $(document).on('click', '.delete-btn', function () {
                let personId = $(this).data('id');
                if (confirm("Are you sure you want to delete this person?")) {
                    $.ajax({
                        url: `/people/${personId}`,
                        method: 'DELETE',
                        success: function (response) {
                            $('#successMessage').html('<div class="alert alert-success">' + response.success + '</div>');
                            fetchPeople();
                        }
                    });
                }
            });

            $('#search').on('keyup', function () {
                let query = $(this).val();
                $.ajax({
                    url: "<?php echo e(route('people.index')); ?>",
                    method: 'GET',
                    data: { search: query },
                    success: function (response) {
                        $('#peopleTable').html(response);
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH /var/www/resources/views/people/index.blade.php ENDPATH**/ ?>