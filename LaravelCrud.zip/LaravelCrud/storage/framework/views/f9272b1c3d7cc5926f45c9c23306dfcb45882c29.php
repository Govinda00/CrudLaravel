<?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($person->name); ?></td>
    <td><?php echo e($person->email); ?></td>
    <td><?php echo e($person->phone); ?></td>
    <td><?php echo e($person->gender); ?></td>
    <td><img src="<?php echo e(asset('storage/' . $person->image)); ?>" alt="Person Image" style="width: 100px;"></td>
    <td>
        <button class="btn btn-success edit-btn" data-id="<?php echo e($person->id); ?>">Edit</button>
        <button class="btn btn-danger delete-btn" data-id="<?php echo e($person->id); ?>">Delete</button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/resources/views/people/partials/table.blade.php ENDPATH**/ ?>